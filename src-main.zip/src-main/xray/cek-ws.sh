#!/bin/bash
# SL
# ==========================================
# Color
GREEN='\033[0;32m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'
yl='\e[32;1m'
bl='\e[36;1m'
gl='\e[32;1m'
rd='\e[31;1m'
mg='\e[0;95m'
blu='\e[34m'
op='\e[35m'
or='\033[1;33m'
bd='\e[1m'
color1='\e[031;1m'
color2='\e[34;1m'
color3='\e[0m'
# Getting
# ==========================================
# Getting
MYIP=$(wget -qO- ipinfo.io/ip);
echo "Checking VPS"
IZIN=$( curl ipinfo.io/ip | grep $MYIP )
if [ $MYIP = $MYIP ]; then
echo -e "${NC}${GREEN}Permission Accepted...${NC}"
else
echo -e "${NC}${RED}Permission Denied!${NC}";
echo -e "${NC}${LIGHT}Fuck You!!"
fi
clear
echo " "
echo " "
if [ -e "/var/log/xray/access.log" ]; then
        LOG="/var/log/xray/access.log";
fi
if [ -e "/var/log/xray/error.log" ]; then
        LOG="/var/log/xray/error.log";
fi
#
if [ -f "/var/log/xray/access.log" ]; then
echo ""
anjay=$(netstat -anp | grep ESTABLISHED | grep xray | awk '{print $4,$5}' | sort | uniq);
rm -r /tmp/anjay-login.txt
clear
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "\E[44;1;39m            ⇱ MENU CEK XRAY Login ⇲             \E[0m"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "\E[44;1;39m            ⇱ XRAY Login ⇲             \E[0m"
echo -e "\E[44;1;39m  ⇱ Source IP Address  |  Destination IP/Website ⇲             \E[0m"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo "----------------------------------------------";
        netstat -anp | grep ESTABLISHED | grep xray | awk '{print $4,$5}' | sort | uniq > /tmp/anjay-login.txt
        cat /tmp/anjay-login.txt
fi
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "\E[44;1;39m            ⇱ XRAY Login ⇲             \E[0m"
echo -e "\E[44;1;39m  ⇱ Source IP Address  |  Destination IP/Website ⇲             \E[0m"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
#
if [ -f "/var/log/xray/access.log" ]; then
echo ""
rm -r /tmp/xray-login.txt
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "\E[44;1;39m            ⇱ MENU CEK XRAY Info Live⇲             \E[0m"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "\E[44;1;39m            ⇱ XRAY Info Live⇲             \E[0m"
echo -e "\E[44;1;39m  ⇱ Tahun/Bulan/Tanggal  |  Jam | IP Address Publik | Situs/IP Yang Di Buka⇲             \E[0m"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo "----------------------------------------------";
        cat /var/log/xray/access.log | awk '{print $0}' | tail -n 500 | cut -d " " -f 1,2,3,5 | sort | uniq > /tmp/xray-login.txt
        cat /tmp/xray-login.txt
fi
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "\E[44;1;39m            ⇱ XRAY Info Live⇲             \E[0m"
echo -e "\E[44;1;39m  ⇱ Tahun/Bulan/Tanggal  |  Jam | IP Address Publik| Situs/IP Yang Di Buka⇲             \E[0m"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "\E[44;1;39m            ⇱ Script MANTAPV3 By SL⇲             \E[0m"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo ""
echo "";
